from setuptools import setup

setup(
    name="foo_plugin",
    py_modules=['foo_plugin'],
    entry_points="""
       [plugin_example]
       plugin_name1 = foo_plugin:func
    """,
)

