
def func(name):
    return 'Hello %s (by foo_plugin)' % name

