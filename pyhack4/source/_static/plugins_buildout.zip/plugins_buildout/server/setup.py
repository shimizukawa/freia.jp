from setuptools import setup, find_packages

setup(
    name="practice.server",
    namespace_packages=['practice'],
    packages=find_packages('src'),
    package_dir={'': 'src'},
    entry_points="""
       [console_scripts]
       run_all = practice.server:run_all
    """,
)

