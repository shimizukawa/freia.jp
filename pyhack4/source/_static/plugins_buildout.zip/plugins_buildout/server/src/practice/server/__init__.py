import sys, pkg_resources

def run_all():
    if len(sys.argv) < 2:
        arg1 = 'SERVER'
    else:
        arg1 = sys.argv[1]

    for plugin in pkg_resources.iter_entry_points('practice.plugin'):
        print '## call plugin: %s:%s' % (plugin.module_name, plugin.name)
        print plugin.load()(arg1)
        print

    print '## plugins call finished'
