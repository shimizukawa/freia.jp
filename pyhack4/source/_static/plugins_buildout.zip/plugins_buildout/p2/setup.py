from setuptools import setup, find_packages

setup(
    name="practice.plugin2",
    namespace_packages=['practice'],
    packages=find_packages('src'),
    package_dir={'': 'src'},
    entry_points="""
       [practice.plugin]
       plugin2_name1 = practice.plugin2:plugin2
    """,
)

