
def plugin2(name):
    return 'Hello %s (by plugin2)' % name

