from setuptools import setup, find_packages

setup(
    name="practice.plugin1",
    namespace_packages=['practice'],
    packages=find_packages('src'),
    package_dir={'': 'src'},
    entry_points="""
       [practice.plugin]
       plugin_name1 = practice.plugin1:plugin1
    """,
)

