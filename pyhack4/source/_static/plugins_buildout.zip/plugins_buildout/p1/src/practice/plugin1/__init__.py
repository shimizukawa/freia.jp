
def plugin1(name):
    return 'Hello %s (by plugin1)' % name

