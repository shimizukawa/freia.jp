
def func(name):
    return 'Hello %s (by bar_plugin)' % name

