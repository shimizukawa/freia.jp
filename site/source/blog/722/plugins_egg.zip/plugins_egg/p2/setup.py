from setuptools import setup

setup(
    name="bar_plugin",
    py_modules=['bar_plugin'],
    entry_points="""
       [plugin_example]
       plugin_name2 = bar_plugin:func
    """,
)

