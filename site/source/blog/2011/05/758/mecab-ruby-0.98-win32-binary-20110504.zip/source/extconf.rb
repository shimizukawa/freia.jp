require 'mkmf'

$CFLAGS += ' -IC:\Develop\Mecab\sdk'
$LOCAL_LIBS += ' libmecab.lib'
$LIBPATH << 'C:\Develop\Mecab\sdk'

have_header('mecab.h') && create_makefile('MeCab')
